﻿
--- Faith Mazzone ---
--- Lab 8 ---


DROP TABLE IF EXISTS People;
DROP TABLE IF EXISTS Directors;
DROP TABLE IF EXISTS Actors;
DROP TABLE IF EXISTS Movies;
DROP TABLE IF EXISTS MovieDirectors;
DROP TABLE IF EXISTS MovieActors;

-- People --
CREATE TABLE People (
  pName        text UNIQUE,
  address      text,
  spouseName   text,
 primary key(pName, address)
);


-- Directors --
CREATE TABLE Directors (
  pName               text references People(pName),
  filmSchoolAttended  text,
  DGAnniversaryDate  date,
  favouriteLensMaker  text,
 primary key(pName)
);        


-- Actors --
CREATE TABLE Actors (
  pName              text references People(pName),
  birthDate          date,
  hairColour         text,
  eyeColour          text,
  heightInInches     int,
  weight             int,
  favouriteColour    text,
  SAGAnniversaryDate date,
 primary key(pName)
);


-- Movies -- 
CREATE TABLE Movies (
  mName                  text,
  yearReleased           int,    
  MPAANumber             int,
  domesticBoxOfficeSales int,
  DVDBlueraySale         int,
 primary key(MPAANumber)
);


-- MovieDirectors --
CREATE TABLE MovieDirectors (
  MPAANumber  int references Movies(MPAANumber),
  pName       text references People(pName),
 primary key(MPAANumber)
);        


-- MovieActors --
CREATE TABLE MovieActors (
  MPAANumber  int references Movies(MPAANumber),
  pName       text references People(pName),
 primary key(MPAANumber)
);        




--- Searching for all directors with whom Roger Moore has worked ---

select pName
from   People
where  pName in (select pName
		   from MovieDirectors 
		  where MPAANumber in (select MPAANumber
				         from MovieActors
				        where pName = 'Roger Moore')
		)